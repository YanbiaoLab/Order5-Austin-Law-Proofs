"""Read-only structural equation binding check; no Lean import or execution."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent


def parse(text):
    text = text.replace('«', '').replace('»', '').replace('◇', '*')
    tokens = re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[()*=]', text)
    assert re.sub(r'\s+', '', text) == ''.join(tokens), 'Unexpected equation syntax'
    pos = 0
    def atom():
        nonlocal pos
        t = tokens[pos]; pos += 1
        if t == '(':
            out = expr(); assert tokens[pos] == ')'; pos += 1
            return out
        assert re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', t)
        return t
    def expr():
        nonlocal pos
        out = atom()
        while pos < len(tokens) and tokens[pos] == '*':
            pos += 1; out = (out, atom())
        return out
    left = expr(); assert tokens[pos] == '='; pos += 1
    right = expr(); assert pos == len(tokens)
    return left, right


def main():
    manifest = json.loads((ROOT/'manifest.json').read_text(encoding='utf-8-sig'))
    early = []
    for entry in manifest['entries']:
        folder = ROOT/'certificates'/f"Equation{entry['eq1_id']}"
        lean = (folder/'JudgeProblem.lean').read_text(encoding='utf-8-sig')
        for name, stop, field in [('EquationLHS', 'EquationRHS', 'equation1'), ('EquationRHS', 'Goal', 'equation2')]:
            block = lean.split('def '+name, 1)[1]
            block = re.split(r'(?:@\[reducible\]\s*)?(?:def|abbrev) '+stop, block, maxsplit=1)[0]
            body = block.split(':=', 1)[1].strip()
            assert body.startswith('∀ ')
            equation = body.split(',', 1)[1].strip()
            assert parse(equation) == parse(entry[field]), (entry['eq1_id'], field)
        assert re.search(r'∃\s*\(G\s*:\s*Type\)\s*\(_\s*:\s*Magma G\),\s*EquationLHS G\s*∧\s*¬\s*EquationRHS G', lean)
        cert = (folder/'Submission.lean').read_text(encoding='utf-8-sig')
        assert 'import JudgeProblem' in cert
        receipt = json.loads((folder/'judge_acceptance.json').read_text(encoding='utf-8-sig'))
        if not receipt['receipt_contains_problem_text']:
            early.append(entry['eq1_id'])
    print(json.dumps(dict(status='PASS_EXACT_EQUATION_AST_BINDINGS', count=len(manifest['entries']),
                          early_receipts_without_problem_text=early, lean_judge_rerun=False)))


if __name__ == '__main__':
    main()
