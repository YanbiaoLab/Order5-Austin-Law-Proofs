import JudgeMagma.Magma

@[reducible] def EquationLHS (G : Type _) [Magma G] : Prop :=
  ∀ («x» : G) («y» : G) («z» : G), «x» = (((«y» ◇ «y») ◇ («x» ◇ («x» ◇ «z»))) ◇ «z»)

@[reducible] def EquationRHS (G : Type _) [Magma G] : Prop :=
  ∀ («x» : G) («y» : G), «x» = «y»

abbrev Goal : Prop :=
  ∃ (G : Type) (_ : Magma G), EquationLHS G ∧ ¬ EquationRHS G
