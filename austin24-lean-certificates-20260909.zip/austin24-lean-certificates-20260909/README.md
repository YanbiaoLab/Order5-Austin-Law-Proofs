# 24 个后续 Austin 候选的 Lean 证书

本包收集相对原论文 32 个编号基线的后续 24 个编号（12 对对偶）。
它不是 24 个全球首发结果的声明；E12857/E33436 与固定 ALPS 历史记录重合。

每题独立保存在 `certificates/EquationN/`：

- `Submission.lean`：与历史 Judge accepted 回执的 SHA-256 完全一致的证书原文件。
- `JudgeProblem.lean`：该题精确的源等式、E2 和 Goal 定义，原样复制。
- `problem.json`：对应方程文本及编号。
- `judge_acceptance.json`：从历史回执摘录的状态、证书绑定、允许公理和版本信息；不含内部服务地址。

目标不是证明 E_n 蕴含 E2，而是证明它的反例存在：

```lean
abbrev Goal : Prop :=
  ∃ (G : Type) (_ : Magma G), EquationLHS G ∧ ¬ EquationRHS G
```

其中 `EquationLHS = E_n`，`EquationRHS = E2 = ∀ x y, x = y`。
`Submission.lean` 中的入口为 `submission`。不同题使用相同入口和模块名，
所以必须逐目录独立编译，不能把 24 份文件直接拼成一个 Lean 模块。

## 浏览与检查

`INDEX.md` 列出全部方程、证书链接、字节数和哈希。
`manifest.json` 保存每一个打包文件的完整 SHA-256；`verify_hashes.ps1`
只读检查这些文件与清单是否一致。

```powershell
pwsh -File ./verify_hashes.ps1
```

本次整理核对了历史回执的 `accepted / ACCEPTED / false`、源/目标编号、
证书字节哈希，以及归档方程文本与固定候选集的一致性。部分早期回执没有
内嵌方程文本，摘录中的 `receipt_contains_problem_text` 如实标记；不会补造。
`verify_bindings.py` 进一步逐题解析 `JudgeProblem.lean` 的等式语法树，
核对其与清单中的 E_n、E2 一致。没有重新运行搜索或调用 Judge。
本包不附带 Lean/Mathlib 工具链及 `JudgeMagma.Magma` 编译依赖。
重放需使用与回执匹配的 Judge Lean 项目环境，先编译该题 `JudgeProblem.lean`，
再编译 `Submission.lean`；普通全新 Lean 项目不一定能直接编译。

原搜索目录、论文目录和原证书都未修改。`collect.ps1` 是此次整理脚本；
它拒绝覆盖已经存在的 `certificates/` 目录。
