$ErrorActionPreference = 'Stop'
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') | ConvertFrom-Json
if ($manifest.count -ne 24 -or @($manifest.entries).Count -ne 24) { throw 'Expected 24 entries' }
$checked = 0
foreach ($entry in $manifest.entries) {
    if ($entry.eq2_id -ne 2) { throw 'Unexpected target' }
    foreach ($expected in $entry.files) {
        $resolved = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $expected.path))
        $prefix = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\','/') + [IO.Path]::DirectorySeparatorChar
        if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path escaped package' }
        $file = Get-Item -LiteralPath $resolved
        $actual = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -cne $expected.sha256 -or $file.Length -ne $expected.bytes) { throw "Mismatch: $($expected.path)" }
        $checked++
    }
    $receipt = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot "certificates/Equation$($entry.eq1_id)/judge_acceptance.json") | ConvertFrom-Json
    if ($receipt.status -cne 'accepted' -or $receipt.error_code -cne 'ACCEPTED' -or $receipt.verdict -cne 'false') { throw 'Receipt not accepted' }
    if ($receipt.certificate_sha256 -cne $entry.files[0].sha256 -or $receipt.eq1_id -ne $entry.eq1_id -or $receipt.eq2_id -ne 2) { throw 'Receipt binding mismatch' }
}
Write-Output "PASS: 24 certificates; $checked file hashes verified; no Lean or Judge rerun"
