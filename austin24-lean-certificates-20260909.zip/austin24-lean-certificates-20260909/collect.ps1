$ErrorActionPreference = 'Stop'
$sourceRoot = 'D:/Desktop/ai for math/owner-section-search-20260907/new_certificates'
$auditPath = 'D:/Desktop/ai for math/cav-infinite-countermodels-20260909/input/evidence/merged_evidence_audit.json'
$datasetPath = 'D:/Desktop/ai for math/cav-infinite-countermodels-20260909/input/data/candidate96.jsonl'
$audit = Get-Content -Raw -LiteralPath $auditPath | ConvertFrom-Json
$ids = @($audit.later_exact_judge_ids)
if ($ids.Count -ne 24 -or @($ids | Sort-Object -Unique).Count -ne 24) { throw 'Expected 24 distinct IDs' }
$data = @{}
Get-Content -LiteralPath $datasetPath | ForEach-Object { $r = $_ | ConvertFrom-Json; $data[[int]$r.eq1_id] = $r }
$targetRoot = Join-Path $PSScriptRoot 'certificates'
if (Test-Path -LiteralPath $targetRoot) { throw 'Refusing to overwrite certificate package' }
$checked = @()
foreach ($id in $ids) {
    $src = Join-Path $sourceRoot "Equation$id"
    $problem = Get-Content -Raw -LiteralPath (Join-Path $src 'problem.json') | ConvertFrom-Json
    $receipt = Get-Content -Raw -LiteralPath (Join-Path $src 'judge_verification.json') | ConvertFrom-Json
    $cert = Get-Item -LiteralPath (Join-Path $src 'Submission.lean')
    $hash = (Get-FileHash -LiteralPath $cert.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($receipt.eq1_id -ne $id -or $receipt.eq2_id -ne 2 -or $problem.eq1_id -ne $id -or $problem.eq2_id -ne 2) { throw "Wrong exact pair $id" }
    if ($receipt.response.status -cne 'accepted' -or $receipt.response.error_code -cne 'ACCEPTED' -or $receipt.response.verdict -cne 'false') { throw "Not accepted $id" }
    if ($hash -cne $receipt.certificate_sha256 -or $cert.Length -ne $receipt.certificate_bytes) { throw "Certificate binding mismatch $id" }
    foreach ($field in @('equation1', 'equation2')) {
        if ($problem.$field -cne $data[[int]$id].$field) { throw "Frozen equation text mismatch $id $field" }
        if ($null -ne $receipt.problem -and $problem.$field -cne $receipt.problem.$field) { throw "Receipt equation text mismatch $id $field" }
    }
    if ($cert.Length -gt 1000000) { throw "Byte cap exceeded $id" }
    $code = Get-Content -Raw -LiteralPath $cert.FullName
    if ($code -match '\b(grind|sorry|admit|native_decide)\b') { throw "Forbidden proof construct $id" }
    if (-not (Test-Path -LiteralPath (Join-Path $src 'JudgeProblem.lean'))) { throw "Missing JudgeProblem $id" }
    $unapproved = @($receipt.response.axioms | Where-Object { $_ -notin @('propext', 'Classical.choice', 'Quot.sound') })
    if ($unapproved.Count -gt 0) { throw "Unapproved axiom $id" }
    $checked += [pscustomobject]@{id=$id; src=$src; problem=$problem; receipt=$receipt; bytes=$cert.Length; sha256=$hash}
}
New-Item -ItemType Directory -Path $targetRoot | Out-Null
$entries = @()
$index = [System.Collections.Generic.List[string]]::new()
$index.Add('# 24 个精确 E_n → E2 反例证书')
$index.Add('')
$index.Add('每份 Submission.lean 均与其历史 Judge v3 accepted / ACCEPTED / false 回执匹配。')
$index.Add('')
$index.Add('| 编号 | 源等式 | Lean 证书 | 字节 | SHA-256 |')
$index.Add('|---|---|---|---:|---|')
foreach ($row in $checked) {
    $id = $row.id
    $dst = Join-Path $targetRoot "Equation$id"
    New-Item -ItemType Directory -Path $dst | Out-Null
    foreach ($name in @('Submission.lean', 'JudgeProblem.lean', 'problem.json')) {
        Copy-Item -LiteralPath (Join-Path $row.src $name) -Destination (Join-Path $dst $name)
    }
    $excerpt = [ordered]@{
        record_kind='historical_judge_receipt_excerpt'; eq1_id=$id; eq2_id=2
        receipt_contains_problem_text=($null -ne $row.receipt.problem)
        equation1=$row.problem.equation1; equation2=$row.problem.equation2
        certificate_sha256=$row.sha256; certificate_bytes=$row.bytes
        status=$row.receipt.response.status; error_code=$row.receipt.response.error_code
        verdict=$row.receipt.response.verdict; axioms=@($row.receipt.response.axioms)
        service_rev=$row.receipt.response.service_rev
        proof_policy_rev=$row.receipt.response.proof_policy_rev
        source_receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $row.src 'judge_verification.json') -Algorithm SHA256).Hash.ToLowerInvariant()
        note='Historical acceptance; no new Judge submission during packaging. Internal addresses omitted.'
    }
    $excerpt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $dst 'judge_acceptance.json') -Encoding utf8
    $files = @()
    foreach ($name in @('Submission.lean', 'JudgeProblem.lean', 'problem.json', 'judge_acceptance.json')) {
        $file = Get-Item -LiteralPath (Join-Path $dst $name)
        $files += [ordered]@{path="certificates/Equation$id/$name"; bytes=$file.Length; sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
    }
    if ($files[0].sha256 -cne $row.sha256) { throw "Copied bytes changed $id" }
    $entries += [ordered]@{eq1_id=$id; eq2_id=2; equation1=$row.problem.equation1; equation2=$row.problem.equation2; files=$files}
    $index.Add("| E$id | $($row.problem.equation1) | [Submission.lean](certificates/Equation$id/Submission.lean) | $($row.bytes) | $($row.sha256) |")
}
$manifest = [ordered]@{
    date='2026-09-09'; count=$entries.Count; dual_pair_count=12
    scope='24 IDs subsequent to the 32-ID original-paper baseline; not a global novelty assertion'
    verification='Historical pair-ID and certificate-hash audit; archived problem matches frozen source. Early receipts omit problem text. No new Lean/Judge execution.'
    source_id_manifest_sha256=(Get-FileHash -LiteralPath $auditPath -Algorithm SHA256).Hash.ToLowerInvariant()
    entries=$entries
}
$manifest | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Encoding utf8
$index | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'INDEX.md') -Encoding utf8
Write-Output "PACKAGED $($entries.Count) exact accepted certificates"
