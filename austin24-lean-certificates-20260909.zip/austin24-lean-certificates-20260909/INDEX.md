# 24 个精确 E_n → E2 反例证书

每份 Submission.lean 均与其历史 Judge v3 accepted / ACCEPTED / false 回执匹配。

| 编号 | 源等式 | Lean 证书 | 字节 | SHA-256 |
|---|---|---|---:|---|
| E5833 | x = y * (x * (y * ((z * x) * y))) | [Submission.lean](certificates/Equation5833/Submission.lean) | 4851 | 9e562a7201150025335f12548a3bd662e279c458bb34763d43f3cab90ee4a09b |
| E6878 | x = y * (y * ((z * x) * (x * y))) | [Submission.lean](certificates/Equation6878/Submission.lean) | 572996 | 7087715d12994f6d82785c62453eb867c49fbe0abe395049864f6319189be822 |
| E7763 | x = y * (y * ((z * (x * z)) * y)) | [Submission.lean](certificates/Equation7763/Submission.lean) | 22478 | 1ddea7ca8193c986ddd49cd83a9679e30fdf9248a86b7b8835157e68a80af169 |
| E9603 | x = y * ((z * x) * (y * (x * y))) | [Submission.lean](certificates/Equation9603/Submission.lean) | 7070 | eaa5b6f4be09af06481238b3dce3e2fba31195e4152a64603675aa6875f95f8a |
| E11205 | x = y * ((y * (x * y)) * (z * y)) | [Submission.lean](certificates/Equation11205/Submission.lean) | 7496 | 931671a0edcd957a61cc840819442c28e5c9535edfaa7c3f8fc21591b4fbe744 |
| E11280 | x = y * ((y * (z * y)) * (x * y)) | [Submission.lean](certificates/Equation11280/Submission.lean) | 555995 | 57c58f35150b4a03a02de661751d7f1c40ee2504162dd01fdb9fc914457f7db7 |
| E12073 | x = y * (((y * x) * x) * (z * z)) | [Submission.lean](certificates/Equation12073/Submission.lean) | 980416 | bd8dfe4ad981d527b58ae03a419aeb9764970fee8210739301403a181fc6fb09 |
| E12857 | x = y * ((x * (y * (z * z))) * y) | [Submission.lean](certificates/Equation12857/Submission.lean) | 226445 | 6a76979625e9e304bcaaeb4003f40810dc29adffb0f63938c1cc5dfdc8a93c66 |
| E13764 | x = y * ((x * ((z * y) * y)) * y) | [Submission.lean](certificates/Equation13764/Submission.lean) | 211404 | e79475d0ae476b635129b236bb577fa44f9e2cdc0a509df33bf82b6510233915 |
| E13849 | x = y * ((y * ((x * z) * z)) * z) | [Submission.lean](certificates/Equation13849/Submission.lean) | 211396 | 3c134f58a5ce9de6b8d0a03c1cc4661c8b408296763783b27aebc6347799b423 |
| E13992 | x = y * ((z * ((x * y) * y)) * y) | [Submission.lean](certificates/Equation13992/Submission.lean) | 211251 | 35cc2f738b703b5200fc29fc2eca5fb1484e827ae88c515b10c3b2a3cafed0eb |
| E18212 | x = (y * y) * (x * ((x * z) * z)) | [Submission.lean](certificates/Equation18212/Submission.lean) | 321635 | 428051c9f4ae4bde5fbbf0006cb3b1f8ac6507c67533bb3737d54ab6ba8716f8 |
| E27859 | x = ((y * (y * x)) * x) * (z * z) | [Submission.lean](certificates/Equation27859/Submission.lean) | 322023 | e2769d09f3a13d5f6cd4e7657b203f3e78dfd23d4eb97c6db4f725c0eef65782 |
| E32280 | x = (y * ((y * (y * x)) * z)) * y | [Submission.lean](certificates/Equation32280/Submission.lean) | 211685 | 4f557c76653572b15feddf7c7a916d0ad58fb4d63767155a89d3ec33a812578a |
| E32281 | x = (y * ((y * (y * x)) * z)) * z | [Submission.lean](certificates/Equation32281/Submission.lean) | 211830 | e349e5b9c0268f42b29fce7b97b7701cf1c6ccf5abbafe5197e8d0bcd7d844fc |
| E32294 | x = (y * ((y * (y * z)) * x)) * y | [Submission.lean](certificates/Equation32294/Submission.lean) | 211838 | 7a0bcbc67c6683e450d1257a2b506b437245c37fbe282198384fc898d82f06ac |
| E33436 | x = (y * (((z * z) * y) * x)) * y | [Submission.lean](certificates/Equation33436/Submission.lean) | 226903 | 4cc010781739a66edca4123ab40bfb55edad47e1ea8150940811bdcb69e1aa40 |
| E33998 | x = ((y * y) * (x * (x * z))) * z | [Submission.lean](certificates/Equation33998/Submission.lean) | 981340 | 6b09fe36502260a13aed392eb8a07e11f4205c862f4883db7d20964402d51d99 |
| E34778 | x = ((y * x) * ((y * z) * y)) * y | [Submission.lean](certificates/Equation34778/Submission.lean) | 556957 | 47a5f55c75349a7a09649699cdfaf997d6b0e2ab3c4c4e0a86ea8bcf3db0127a |
| E35100 | x = ((y * z) * ((y * x) * y)) * y | [Submission.lean](certificates/Equation35100/Submission.lean) | 8458 | 4fbe075a242b50656ada1dcbd8603a84dfb02223451b072e8e54690acbe56777 |
| E36514 | x = (((y * x) * y) * (x * z)) * y | [Submission.lean](certificates/Equation36514/Submission.lean) | 8032 | 8019b89c1644878c6df3d58d6e79f18af5d54eed46d238bb97721687240a5ba4 |
| E38565 | x = ((y * ((z * x) * z)) * y) * y | [Submission.lean](certificates/Equation38565/Submission.lean) | 23440 | 87db1ede5fd9ae90e76dfa28337788fa11f192c67a270a15a531788542d56b8b |
| E39126 | x = (((y * x) * (x * z)) * y) * y | [Submission.lean](certificates/Equation39126/Submission.lean) | 573962 | 7144111eab0122bc7c446cb006a9f53f42aa87819919d65549ed5fe032984640 |
| E40070 | x = (((y * (x * z)) * y) * x) * y | [Submission.lean](certificates/Equation40070/Submission.lean) | 5813 | e67b9eddb69ab9ef3c9317ddfe03c5ca0f5fb80034c69990c3ea2ef181800034 |
